import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import express from 'express';
import cors from 'cors';
import tachesRouter from './routes/taches.js';
import facturesRouter from './routes/factures.js';
import planningRouter from './routes/planning.js';
import assistantRouter from './routes/assistant.js';
import todosRouter from './routes/todos.js';
import clientsRouter from './routes/clients.js';
import employesRouter from './routes/employes.js';
import automationsRouter from './routes/automations.js';
import evenementsRouter from './routes/evenements.js';
import documentsRouter  from './routes/documents.js';


const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, '../.env') });

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/api/taches', tachesRouter);
app.use('/api/factures', facturesRouter);
app.use('/api/planning', planningRouter);
app.use('/api/assistant', assistantRouter);
app.use('/api/todos', todosRouter);
app.use('/api/clients', clientsRouter);
app.use('/api/employes', employesRouter);
app.use('/api/automations', automationsRouter);
app.use('/api/evenements', evenementsRouter);
app.use('/api/documents', documentsRouter);

app.listen(PORT, () => {
  console.log(`Lexora backend running on port ${PORT}`);
});
